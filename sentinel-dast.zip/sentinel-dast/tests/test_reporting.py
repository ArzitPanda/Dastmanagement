from pathlib import Path
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session
from sentinel_dast.models import Base, Release
from sentinel_dast.services.demo import seed_demo
from sentinel_dast.services.reporting import export_release_html, export_release_pdf, export_release_xlsx

def test_report_exports(tmp_path):
    engine=create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with Session(engine) as session:
        seed_demo(session); session.commit()
        release=session.scalar(select(Release).where(Release.release_key=="REL-PORTAL-2.4"))
        for ext, exporter in [("html",export_release_html),("pdf",export_release_pdf),("xlsx",export_release_xlsx)]:
            target=tmp_path/f"assessment.{ext}"
            exporter(session,release.id,target)
            assert target.exists() and target.stat().st_size > 100
