import pytest
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session
from sentinel_dast.models import Base,Application,Environment,Release,ChangeRequest,ReleaseChangeRequest,TestCase,TestCaseVersion,TestPlan,TestExecution,Finding,FindingObservation
from sentinel_dast.services.workflow import (WorkflowError,transition_release,create_test_execution,
    update_execution_status,coverage_for_release,signoff_blockers,approve_release,create_regression_suite)

@pytest.fixture
def session():
    engine=create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with Session(engine) as s:
        yield s

def fixture_release(s):
    app=Application(app_key="APP1",name="Example")
    s.add(app);s.flush()
    env=Environment(application_id=app.id,name="QA")
    s.add(env);s.flush()
    rel=Release(release_key="REL1",application_id=app.id,version="1.0",status="Draft",environment_id=env.id)
    cr=ChangeRequest(cr_key="CR1",title="Auth change",application_id=app.id)
    tc=TestCase(test_key="TC1",title="Auth baseline",steps="Check login",expected_result="Safe")
    s.add_all([rel,cr,tc]);s.flush()
    s.add(ReleaseChangeRequest(release_id=rel.id,change_request_id=cr.id))
    s.add(TestCaseVersion(test_case_id=tc.id,version=1,snapshot={"title":tc.title}))
    s.flush()
    plan=TestPlan(release_id=rel.id,name="Plan")
    s.add(plan);s.flush()
    return app,env,rel,cr,tc,plan

def test_release_transition_enforced(session):
    _,_,r,_,_,_=fixture_release(session)
    with pytest.raises(WorkflowError): transition_release(session,r.id,"Approved")
    transition_release(session,r.id,"Planned")
    assert r.status=="Planned"

def test_execution_references_version_and_history(session):
    _,env,r,cr,tc,plan=fixture_release(session)
    exe=create_test_execution(session,plan,tc,env.id,cr.id)
    assert exe.test_case_version_id is not None
    update_execution_status(session,exe.id,"Failed","Observed issue")
    assert exe.status=="Failed" and len(exe.history)==2

def test_cr_coverage_detects_gap_then_covered(session):
    _,env,r,cr,tc,plan=fixture_release(session)
    assert coverage_for_release(session,r.id)["uncovered_cr_ids"]==[cr.id]
    create_test_execution(session,plan,tc,env.id,cr.id)
    assert coverage_for_release(session,r.id)["cr_covered"]==1

def test_signoff_requires_ready_and_no_blockers(session):
    _,env,r,cr,tc,plan=fixture_release(session)
    r.status="Ready for Review"
    with pytest.raises(WorkflowError):approve_release(session,r.id,"Security Lead","Reviewed")
    create_test_execution(session,plan,tc,env.id,cr.id)
    with pytest.raises(WorkflowError):approve_release(session,r.id,"Security Lead","Reviewed")
    exe=session.scalar(select(TestExecution))
    update_execution_status(session,exe.id,"Passed","Validated")
    approve_release(session,r.id,"Security Lead","Reviewed results and evidence")
    assert r.status=="Approved"

def test_regression_suite_includes_mandatory(session):
    app,env,r,cr,tc,plan=fixture_release(session)
    tc.mandatory=True;tc.regression_eligible=True
    suite,cases=create_regression_suite(session,r.id,None)
    assert suite.id and tc in cases
