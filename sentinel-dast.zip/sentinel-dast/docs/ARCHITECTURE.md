# Architecture

Sentinel DAST uses a layered, local-first architecture.

- **Presentation:** PySide6 Qt Widgets. UI classes call service functions and do not contain scan logic.
- **Domain/service layer:** workflow validation, coverage calculations, sign-off checks, evidence storage, demo setup, and reporting.
- **Persistence:** SQLAlchemy 2.x models with SQLite foreign keys enabled. Services use explicit sessions/transactions.
- **Files:** attachments are copied into a managed local evidence directory and tracked by SHA-256, media type, size, and original filename.
- **Reports:** ReportLab PDF, openpyxl XLSX, escaped HTML.
- **Future extension:** the ORM/service boundary can move to PostgreSQL by changing the database URL and validating dialect-specific constraints. Multi-user access requires identity, authorization, concurrency, and audit hardening; it is not implied by the current desktop shell.

## Safety boundaries

No active scanner is launched automatically. A future ZAP integration must validate target scope, environment, credentials configuration, and explicit analyst confirmation. Production scanning must remain opt-in and policy-controlled.
