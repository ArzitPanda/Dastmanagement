# Data model

Core relationships:

- `Application` 1—N `Environment`; `Application` 1—N `Release`.
- `Release` N—N `ChangeRequest` through `ReleaseChangeRequest`.
- `TestCase` has immutable version snapshots represented by `TestCaseVersion`.
- `TestSuite` N—N versioned test cases through `TestSuiteMembership`.
- `TestPlan` belongs to a release; `TestExecution` belongs to a plan and references a specific `TestCaseVersion`.
- `TestExecutionHistory` preserves status transitions and result notes.
- `Finding` is a durable vulnerability identity; `FindingObservation` records release/CR/execution-specific observations.
- `DefectReference` links external engineering tickets without coupling the domain to one tracker.
- `RegressionSuite` belongs to a target release and `RegressionMembership` records the source release and source finding where applicable.
- `ScanRun` records imported/manual scanner run metadata; `ImportedScanFinding` preserves normalized import candidates and duplicate-review status.
- `EvidenceAttachment` stores file metadata and a managed path; evidence content stays outside the database.
- `RiskAcceptance` and `Approval` are explicit records. `ActivityEvent` records significant changes.
- `SavedFilter` and `ApplicationConfiguration` support local productivity and preferences.

Historical execution references a version snapshot rather than the mutable current test case. Important entities are archived rather than hard-deleted. Cascading deletes are intentionally limited; service-level deletion policies should preserve security history.
