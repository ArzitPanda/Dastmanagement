# Security notes

- Local SQLite data and evidence are not encrypted by this application. Protect the workstation with full-disk encryption and OS access controls.
- Treat reports, exports, database backups, and evidence as potentially sensitive.
- Scanner credentials are not part of this initial build. Do not add credentials to source control, logs, or exported reports.
- No active scan is launched by the app. Future scanner integrations must validate scope and environment, require explicit user confirmation, and record the action in the audit log.
- This build is not a multi-user authorization system. Local actor names and approval records are workflow metadata, not cryptographic identity assertions.
- Run a code review and threat model before handling real production security evidence.
