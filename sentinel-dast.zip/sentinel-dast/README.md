# Sentinel DAST

**Sentinel DAST** is a local-first desktop workspace for managing DAST release testing, CR coverage, findings, retests, regression planning, evidence, and security reporting.

> **Status:** early functional foundation (0.1.0). This repository is a working starter, not yet a validated production security product. Review the limitations below before operational use.

## Features in this build

- PySide6 desktop shell with persistent navigation, dark/light themes, searchable module tables, and quick-create actions.
- SQLAlchemy 2.x relational model for applications, environments, releases, CRs, versioned test cases, executions/history, findings/observations, evidence, scan runs, approvals, risk acceptances, regression suites, and audit events.
- SQLite local-first database with foreign keys and transaction-backed operations.
- Fictional demo dataset illustrating multiple applications, releases, CRs, executions, findings, and regression.
- Release sign-off gate that checks open Critical/High findings, pending retests, missing CR coverage, and explicit authorized approval.
- Excel and PDF report generation; HTML release assessment output.
- Import/export starter utilities, backup/restore helpers, tests for core business rules.
- No scanner is started automatically. Active scan integration is intentionally not enabled in this initial build.

## Requirements

- Python 3.12+
- Windows, macOS, or Linux desktop environment
- PySide6-compatible display environment

## Install and launch

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e ".[dev]"
python -m sentinel_dast.main
```

The database is created under `~/.sentinel-dast/sentinel.db` by default. Set `SENTINEL_DAST_HOME` to change the data directory.

## Demo mode

Run:

```bash
python -m sentinel_dast.main --seed-demo
```

The demo records are explicitly marked fictional. Use **Settings → Demo data** to inspect demo status. The data layer exposes a dedicated `clear_demo_data()` method; it only deletes records flagged as demo data and is not a general database reset.

## Reports

The report service can generate release assessments in PDF, HTML, and XLSX formats. From the app, select a release and use **Reports & Evidence**. Programmatic usage is available through `sentinel_dast.services.reporting`.

## Backup and restore

Use **Settings → Backup database** to create a timestamped SQLite backup. Backups include the database; evidence files are stored separately under the application data directory and should be copied with the database for a complete recovery. Restore only while the app is closed, verify the backup source, and retain an offline protected copy.

SQLite is **not encrypted at rest by this application**. Use OS disk encryption and restrict access to the local data directory. Evidence can contain secrets or personal data: avoid uploading real evidence to public repositories or reports.

## Security and scope

- The app does not launch scans on release creation.
- Active scanning against Production is not supported by default. Any future scanner integration must require explicit analyst confirmation, approved scope, and environment validation.
- Never put credentials, session tokens, production evidence, or real scan output in source control.
- HTML report values are escaped before rendering.
- Evidence attachments are copied into a managed directory with SHA-256 metadata and size/type validation.
- Local actor identity is currently entered/configured locally; this is not authenticated multi-user access.
- Risk acceptance and sign-off are workflow records, not a replacement for enterprise identity, approval, or policy controls.

## Architecture

```text
sentinel_dast/
  main.py                 application bootstrap
  config.py               local configuration and paths
  db.py                   engine/session/unit-of-work helpers
  models.py               normalized SQLAlchemy domain model
  services/
    workflow.py            release/coverage/sign-off rules
    demo.py                fictional demo records
    evidence.py            managed evidence storage and checksums
    reporting.py           PDF/HTML/XLSX reports
    backup.py              consistent backup/restore helpers
  ui/
    main_window.py         shell, navigation, tables, quick actions
    theme.py               semantic dark/light design tokens
tests/
  test_workflow.py
docs/
  ARCHITECTURE.md
  DATA_MODEL.md
```

## Tests

```bash
pytest
```

## Packaging

```bash
pip install pyinstaller
pyinstaller --noconfirm --windowed --name SentinelDAST -m sentinel_dast.main
```

Validate the package on each target OS. PyInstaller bundles should be built on the target OS.

## Roadmap / current limitations

This initial implementation establishes the domain model, desktop shell, demo data, sign-off rules, evidence handling, reporting, and baseline tests. Full production readiness still requires richer edit/detail forms for every entity, Alembic revision history, authenticated multi-user authorization, comprehensive import mapping and duplicate review UI, complete regression comparison UX, scanner-specific ZAP API integration, broader test coverage, accessibility review, and security review. Do not use this build as the sole source of truth for release approval until those controls are implemented and validated.
