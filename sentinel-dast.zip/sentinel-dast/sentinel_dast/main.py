from __future__ import annotations
import argparse,sys
from PySide6.QtWidgets import QApplication
from sentinel_dast.db import init_db,session_scope
from sentinel_dast.ui.main_window import MainWindow
from sentinel_dast.services.demo import seed_demo

def main():
    parser=argparse.ArgumentParser(description="Sentinel DAST desktop application")
    parser.add_argument("--seed-demo",action="store_true",help="seed clearly fictional demonstration data")
    args=parser.parse_args()
    init_db()
    if args.seed_demo:
        with session_scope() as s:seed_demo(s)
    app=QApplication(sys.argv);app.setApplicationName("Sentinel DAST")
    window=MainWindow();window.show()
    return app.exec()
if __name__=="__main__":raise SystemExit(main())
