from __future__ import annotations
from contextlib import contextmanager
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker
from sentinel_dast.config import database_url
from sentinel_dast.models import Base

_engine = None
_Session = None

def init_db(url: str | None = None):
    global _engine, _Session
    _engine = create_engine(url or database_url(), future=True)
    if (_engine.url.get_backend_name() == "sqlite"):
        @event.listens_for(_engine, "connect")
        def _fk_on(dbapi_connection, _):
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()
    _Session = sessionmaker(bind=_engine, expire_on_commit=False, future=True)
    Base.metadata.create_all(_engine)
    return _engine

def session_factory():
    if _Session is None:
        init_db()
    return _Session

@contextmanager
def session_scope():
    session = session_factory()()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
