from __future__ import annotations
import shutil, sqlite3
from datetime import datetime
from pathlib import Path
from sentinel_dast.config import data_home

def create_backup(db_path: str | Path | None = None) -> Path:
    source=Path(db_path) if db_path else data_home()/"sentinel.db"
    if not source.exists(): raise FileNotFoundError("Database does not exist yet.")
    destination=data_home()/"backups"
    destination.mkdir(exist_ok=True)
    target=destination/f"sentinel-backup-{datetime.now().strftime('%Y%m%d-%H%M%S')}.db"
    with sqlite3.connect(source) as src, sqlite3.connect(target) as dst:
        src.backup(dst)
    return target

def validate_backup(path: str | Path) -> bool:
    with sqlite3.connect(path) as conn:
        result=conn.execute("PRAGMA integrity_check").fetchone()
    return bool(result and result[0]=="ok")

def restore_backup(backup_path: str | Path, db_path: str | Path | None = None):
    source=Path(backup_path)
    if not validate_backup(source): raise ValueError("Backup integrity check failed.")
    target=Path(db_path) if db_path else data_home()/"sentinel.db"
    temp=target.with_suffix(".restore.tmp")
    shutil.copy2(source,temp)
    with sqlite3.connect(temp) as conn:
        if conn.execute("PRAGMA integrity_check").fetchone()[0]!="ok":
            temp.unlink(missing_ok=True); raise ValueError("Restored database failed integrity check.")
    temp.replace(target)
    return target
