from __future__ import annotations
from datetime import datetime, timezone
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from sentinel_dast.models import (
    Release, ReleaseChangeRequest, ChangeRequest, TestPlan, TestExecution,
    TestCase, TestCaseVersion, TestExecutionHistory, Finding, FindingObservation,
    Approval, ActivityEvent, RegressionSuite, RegressionMembership, RiskAcceptance
)

EXECUTION_STATUSES = {"Not Started", "In Progress", "Passed", "Failed", "Blocked", "Not Applicable", "Needs Retest"}
RELEASE_TRANSITIONS = {
    "Draft": {"Planned"},
    "Planned": {"In Testing", "Draft"},
    "In Testing": {"Blocked", "Ready for Review", "Planned"},
    "Blocked": {"In Testing", "Ready for Review"},
    "Ready for Review": {"Approved", "Rejected", "In Testing"},
    "Rejected": {"Planned", "In Testing"},
    "Approved": {"Closed", "In Testing"},
    "Closed": {"In Testing"},
}
OPEN_FINDING_STATUSES = {"Open", "Triaged", "Confirmed", "In Remediation", "Fixed", "Ready for Retest", "Reopened"}

class WorkflowError(ValueError): pass

def log_event(session: Session, action: str, entity_type: str, entity_id: int,
              before=None, after=None, note="", actor="Local analyst"):
    session.add(ActivityEvent(actor=actor, action=action, entity_type=entity_type,
                              entity_id=entity_id, before_value=before, after_value=after, note=note))

def transition_release(session: Session, release_id: int, new_status: str, actor="Local analyst"):
    release = session.get(Release, release_id)
    if not release: raise WorkflowError("Release not found.")
    if new_status not in RELEASE_TRANSITIONS.get(release.status, set()):
        raise WorkflowError(f"Invalid release transition: {release.status} → {new_status}.")
    before = {"status": release.status}
    release.status = new_status
    if new_status in {"In Testing", "Ready for Review", "Approved", "Rejected", "Closed"}:
        release.updated_at = datetime.now(timezone.utc)
    log_event(session, "release.status_changed", "Release", release.id, before, {"status": new_status}, actor=actor)
    return release

def create_test_execution(session: Session, plan: TestPlan, test_case: TestCase, environment_id: int,
                          change_request_id: int | None = None, assignee=""):
    version = session.scalar(select(TestCaseVersion).where(
        TestCaseVersion.test_case_id == test_case.id,
        TestCaseVersion.version == test_case.current_version
    ))
    if not version:
        snapshot = {"title": test_case.title, "steps": test_case.steps,
                    "expected_result": test_case.expected_result, "category": test_case.category}
        version = TestCaseVersion(test_case_id=test_case.id, version=test_case.current_version,
                                  snapshot=snapshot, change_note="Initial snapshot")
        session.add(version)
        session.flush()
    execution = TestExecution(
        execution_key=f"EXE-{datetime.now(timezone.utc).strftime('%y%m%d%H%M%S%f')}",
        test_plan_id=plan.id, test_case_id=test_case.id, test_case_version_id=version.id,
        change_request_id=change_request_id, environment_id=environment_id, assignee=assignee,
        priority=test_case.risk_level, status="Not Started"
    )
    session.add(execution)
    session.flush()
    session.add(TestExecutionHistory(execution_id=execution.id, old_status="", new_status="Not Started",
                                     notes="Execution planned"))
    log_event(session, "execution.created", "TestExecution", execution.id, after={"status":"Not Started"})
    return execution

def update_execution_status(session: Session, execution_id: int, new_status: str, notes: str = "",
                            actual_observations: str = "", actor="Local analyst"):
    if new_status not in EXECUTION_STATUSES: raise WorkflowError("Unknown execution status.")
    execution = session.get(TestExecution, execution_id)
    if not execution: raise WorkflowError("Execution not found.")
    old = execution.status
    execution.status = new_status
    execution.actual_observations = actual_observations or execution.actual_observations
    execution.justification = notes or execution.justification
    execution.executed_at = datetime.now(timezone.utc) if new_status in {"Passed","Failed","Blocked","Not Applicable","Needs Retest"} else execution.executed_at
    session.add(TestExecutionHistory(execution_id=execution.id, old_status=old, new_status=new_status, notes=notes, actor=actor))
    log_event(session, "execution.status_changed", "TestExecution", execution.id,
              {"status":old}, {"status":new_status,"notes":notes}, actor=actor)
    return execution

def coverage_for_release(session: Session, release_id: int):
    cr_ids = list(session.scalars(select(ReleaseChangeRequest.change_request_id).where(
        ReleaseChangeRequest.release_id == release_id)))
    covered = set(session.scalars(select(TestExecution.change_request_id).join(TestPlan).where(
        TestPlan.release_id == release_id, TestExecution.change_request_id.is_not(None))))
    return {"cr_total":len(cr_ids), "cr_covered":len(set(cr_ids)&covered),
            "uncovered_cr_ids":[cid for cid in cr_ids if cid not in covered]}

def release_metrics(session: Session, release_id: int):
    plan_ids = select(TestPlan.id).where(TestPlan.release_id == release_id)
    counts = {status: 0 for status in EXECUTION_STATUSES}
    rows = session.execute(select(TestExecution.status, func.count(TestExecution.id))
                           .where(TestExecution.test_plan_id.in_(plan_ids))
                           .group_by(TestExecution.status)).all()
    counts.update({status: count for status, count in rows})
    return {**counts, **coverage_for_release(session, release_id)}

def signoff_blockers(session: Session, release_id: int):
    blockers=[]
    coverage=coverage_for_release(session, release_id)
    if coverage["uncovered_cr_ids"]:
        blockers.append(f"{len(coverage['uncovered_cr_ids'])} CR(s) have no linked execution coverage")
    plan_ids=select(TestPlan.id).where(TestPlan.release_id==release_id)
    pending=session.scalar(select(func.count(TestExecution.id)).where(
        TestExecution.test_plan_id.in_(plan_ids),
        TestExecution.status.in_(["Not Started","In Progress","Blocked","Needs Retest"]))) or 0
    if pending: blockers.append(f"{pending} execution(s) are pending, blocked, or need retest")
    open_high=session.scalar(select(func.count(Finding.id)).join(FindingObservation).where(
        FindingObservation.release_id==release_id, Finding.severity.in_(["Critical","High"]),
        Finding.status.in_(OPEN_FINDING_STATUSES))) or 0
    if open_high: blockers.append(f"{open_high} open Critical/High finding observation(s)")
    return blockers

def approve_release(session: Session, release_id: int, approver: str, rationale: str):
    release=session.get(Release, release_id)
    if not release: raise WorkflowError("Release not found.")
    if release.status != "Ready for Review":
        raise WorkflowError("Release must be Ready for Review before sign-off.")
    if not approver.strip() or not rationale.strip():
        raise WorkflowError("Authorized approver and rationale are required.")
    blockers=signoff_blockers(session, release_id)
    if blockers: raise WorkflowError("Sign-off blocked: " + "; ".join(blockers))
    approval=Approval(entity_type="Release",entity_id=release.id,decision="Approved",
                      approver=approver.strip(),rationale=rationale.strip())
    session.add(approval)
    before={"status":release.status,"signoff_status":release.signoff_status}
    release.status="Approved"; release.signoff_status="Approved"
    log_event(session,"release.approved","Release",release.id,before,
              {"status":"Approved","signoff_status":"Approved","approver":approver},rationale)
    return approval

def create_regression_suite(session: Session, target_release_id: int, source_release_id: int | None = None):
    suite=RegressionSuite(release_id=target_release_id,source_release_id=source_release_id,
                          name=f"Regression for release #{target_release_id}",status="Planned")
    session.add(suite); session.flush()
    query=select(TestCase).where(TestCase.regression_eligible.is_(True),TestCase.archived.is_(False))
    if source_release_id:
        failed_ids=select(TestExecution.test_case_id).join(TestPlan).where(
            TestPlan.release_id==source_release_id,TestExecution.status.in_(["Failed","Needs Retest"]))
        query=query.where(TestCase.id.in_(failed_ids) | TestCase.mandatory.is_(True))
    cases=session.scalars(query).all()
    for case in cases:
        session.add(RegressionMembership(suite_id=suite.id,test_case_id=case.id,
                                         source_release_id=source_release_id,
                                         reason="Mandatory baseline" if case.mandatory else "Previously failed / regression eligible"))
    log_event(session,"regression.created","RegressionSuite",suite.id,after={"target_release_id":target_release_id,
              "source_release_id":source_release_id,"case_count":len(cases)})
    return suite, cases

def accept_risk(session: Session, finding_id: int, approver: str, rationale: str, expires_at=None):
    if not approver.strip() or not rationale.strip():
        raise WorkflowError("Risk acceptance requires an approver and rationale.")
    finding=session.get(Finding,finding_id)
    if not finding: raise WorkflowError("Finding not found.")
    risk=RiskAcceptance(finding_id=finding_id,approver=approver.strip(),rationale=rationale.strip(),expires_at=expires_at)
    session.add(risk)
    before={"status":finding.status}
    finding.status="Accepted Risk"
    log_event(session,"finding.risk_accepted","Finding",finding.id,before,
              {"status":"Accepted Risk","approver":approver,"rationale":rationale})
    return risk
