from __future__ import annotations
from datetime import datetime, timezone
from html import escape
from pathlib import Path
from sqlalchemy import select
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from openpyxl import Workbook
from sentinel_dast.models import Release, Application, ReleaseChangeRequest, ChangeRequest, TestPlan, TestExecution, Finding, FindingObservation
from sentinel_dast.services.workflow import release_metrics, signoff_blockers

def release_report_data(session, release_id):
    release=session.get(Release,release_id)
    if not release: raise ValueError("Release not found.")
    app=session.get(Application,release.application_id)
    crs=session.scalars(select(ChangeRequest).join(ReleaseChangeRequest).where(ReleaseChangeRequest.release_id==release_id)).all()
    plans=session.scalars(select(TestPlan).where(TestPlan.release_id==release_id)).all()
    executions=[]
    for plan in plans: executions.extend(plan.executions)
    findings=session.scalars(select(Finding).join(FindingObservation).where(FindingObservation.release_id==release_id).distinct()).all()
    return {"generated_at":datetime.now(timezone.utc).isoformat(),"release":release,"application":app,
        "crs":crs,"executions":executions,"findings":findings,"metrics":release_metrics(session,release_id),
        "blockers":signoff_blockers(session,release_id)}

def export_release_html(session, release_id, output_path):
    d=release_report_data(session,release_id); r=d["release"]; app=d["application"]
    rows="".join(f"<tr><td>{escape(x.cr_key)}</td><td>{escape(x.title)}</td><td>{escape(x.status)}</td><td>{escape(x.risk_level)}</td></tr>" for x in d["crs"])
    finding_rows="".join(f"<tr><td>{escape(x.finding_key)}</td><td>{escape(x.title)}</td><td>{escape(x.severity)}</td><td>{escape(x.status)}</td></tr>" for x in d["findings"])
    blockers="".join(f"<li>{escape(x)}</li>" for x in d["blockers"]) or "<li>No configured sign-off blockers detected.</li>"
    html=f"""<!doctype html><html><head><meta charset="utf-8"><title>Sentinel DAST Release Assessment</title>
<style>body{{font:14px system-ui,sans-serif;color:#1d2733;margin:36px}}h1{{color:#1f5f9a}}table{{border-collapse:collapse;width:100%;margin:16px 0}}th,td{{border:1px solid #d8dee7;padding:8px;text-align:left}}th{{background:#eef3f8}}.meta{{color:#596879}}</style></head><body>
<h1>Release Security Assessment</h1><p class="meta">Generated {escape(d['generated_at'])}</p>
<h2>{escape(app.name)} · {escape(r.version)}</h2><p>Environment: {escape(r.environment.name if r.environment else 'Not set')} | Status: {escape(r.status)} | Sign-off: {escape(r.signoff_status)}</p>
<h3>Executive summary</h3><p>CRs: {len(d['crs'])}; executions: {len(d['executions'])}; findings: {len(d['findings'])}. This report reflects stored records at generation time and is not an automated approval.</p>
<h3>Sign-off blockers</h3><ul>{blockers}</ul><h3>Change requests</h3><table><tr><th>CR</th><th>Title</th><th>Status</th><th>Risk</th></tr>{rows}</table>
<h3>Findings</h3><table><tr><th>ID</th><th>Title</th><th>Severity</th><th>Status</th></tr>{finding_rows}</table>
<p class="meta">Security-sensitive evidence and credentials are intentionally excluded from this summary report.</p></body></html>"""
    Path(output_path).write_text(html,encoding="utf-8")
    return Path(output_path)

def export_release_xlsx(session, release_id, output_path):
    d=release_report_data(session,release_id); wb=Workbook()
    ws=wb.active; ws.title="Assessment"
    ws.append(["Sentinel DAST - Release Assessment"]); ws.append(["Generated at",d["generated_at"]])
    ws.append(["Application",d["application"].name]); ws.append(["Release",d["release"].version]); ws.append(["Status",d["release"].status])
    ws.append([]); ws.append(["Metric","Value"])
    for k,v in d["metrics"].items(): ws.append([k, ", ".join(map(str, v)) if isinstance(v, (list, tuple, set)) else v])
    cr=wb.create_sheet("Change Requests"); cr.append(["CR ID","Title","Status","Risk"])
    for x in d["crs"]: cr.append([x.cr_key,x.title,x.status,x.risk_level])
    ex=wb.create_sheet("Executions"); ex.append(["Execution ID","Test Case ID","Status","Assignee","Observations"])
    for x in d["executions"]: ex.append([x.execution_key,x.test_case.test_key if x.test_case else "",x.status,x.assignee,x.actual_observations])
    fs=wb.create_sheet("Findings"); fs.append(["Finding ID","Title","Severity","Confidence","Status","Target"])
    for x in d["findings"]: fs.append([x.finding_key,x.title,x.severity,x.confidence,x.status,x.affected_target])
    for sheet in wb.worksheets:
        sheet.freeze_panes="A2"; sheet.auto_filter.ref=sheet.dimensions
        for col in sheet.columns:
            letter=col[0].column_letter
            sheet.column_dimensions[letter].width=min(max(max(len(str(c.value or "")) for c in col)+2,12),48)
    wb.save(output_path); return Path(output_path)

def export_release_pdf(session, release_id, output_path):
    d=release_report_data(session,release_id); r=d["release"]; app=d["application"]
    styles=getSampleStyleSheet(); story=[Paragraph("Sentinel DAST — Release Security Assessment",styles["Title"]),
        Paragraph(f"{escape(app.name)} / Release {escape(r.version)}",styles["Heading2"]),
        Paragraph(f"Generated: {escape(d['generated_at'])}",styles["Normal"]),Spacer(1,12)]
    story.append(Paragraph("Summary",styles["Heading2"]))
    story.append(Paragraph(f"CRs: {len(d['crs'])} · Executions: {len(d['executions'])} · Findings: {len(d['findings'])}",styles["BodyText"]))
    story.append(Paragraph("Sign-off blockers",styles["Heading2"]))
    for b in d["blockers"] or ["No configured sign-off blockers detected."]: story.append(Paragraph("• "+escape(b),styles["BodyText"]))
    story.append(Spacer(1,12)); story.append(Paragraph("Findings register",styles["Heading2"]))
    table_data=[["Finding ID","Title","Severity","Status"]]
    table_data += [[x.finding_key,x.title[:70],x.severity,x.status] for x in d["findings"]]
    table=Table(table_data,repeatRows=1,colWidths=[85,250,75,100])
    table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#e9eff6")),("GRID",(0,0),(-1,-1),.4,colors.HexColor("#c8d0da")),("VALIGN",(0,0),(-1,-1),"TOP"),("PADDING",(0,0),(-1,-1),6)]))
    story.append(table)
    SimpleDocTemplate(str(output_path),pagesize=landscape(A4),rightMargin=30,leftMargin=30,topMargin=32,bottomMargin=32).build(story)
    return Path(output_path)
