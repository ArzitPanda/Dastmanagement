from sqlalchemy import select
from sentinel_dast.models import (Application,Environment,Release,ChangeRequest,ReleaseChangeRequest,
    TestCase,TestCaseVersion,TestPlan,TestExecution,TestExecutionHistory,Finding,FindingObservation,
    RegressionSuite,RegressionMembership,ActivityEvent)
from sentinel_dast.services.workflow import create_test_execution, update_execution_status, create_regression_suite

def seed_demo(session):
    if session.scalar(select(Application.id).where(Application.is_demo.is_(True))): return False
    a1=Application(app_key="APP-PORTAL",name="Customer Portal (DEMO)",description="Fictional customer web portal.",
        business_owner="Demo Business",technical_owner="Demo Engineering",technology_stack="React, Python API",
        app_type="Web application",base_url="https://qa.example.invalid",criticality="High",data_sensitivity="Confidential",is_demo=True)
    a2=Application(app_key="APP-ORDERS",name="Order API (DEMO)",description="Fictional REST API.",
        business_owner="Demo Commerce",technical_owner="Demo Platform",technology_stack="Java, REST",
        app_type="API",base_url="https://api-qa.example.invalid",criticality="Critical",data_sensitivity="Internal",is_demo=True)
    session.add_all([a1,a2]); session.flush()
    e1=Environment(application_id=a1.id,name="QA",base_url="https://qa.example.invalid",authorized_for_active_scan=True,is_demo=True)
    e2=Environment(application_id=a2.id,name="QA",base_url="https://api-qa.example.invalid",authorized_for_active_scan=True,is_demo=True)
    session.add_all([e1,e2]);session.flush()
    r1=Release(release_key="REL-PORTAL-2.4",application_id=a1.id,version="2.4.0",release_type="Minor",status="In Testing",environment_id=e1.id,owner="Demo Analyst",is_demo=True)
    r2=Release(release_key="REL-PORTAL-2.3",application_id=a1.id,version="2.3.0",release_type="Patch",status="Closed",environment_id=e1.id,owner="Demo Analyst",is_demo=True)
    r3=Release(release_key="REL-ORDERS-1.8",application_id=a2.id,version="1.8.0",release_type="Major",status="Planned",environment_id=e2.id,owner="Demo Analyst",is_demo=True)
    session.add_all([r1,r2,r3]);session.flush()
    crs=[
      ChangeRequest(cr_key="CR-1042",title="Account recovery hardening",application_id=a1.id,category="Authentication",risk_level="High",status="In Progress",affected_components="Identity service",affected_endpoints="/api/recovery",acceptance_criteria="Recovery token expires and is single-use.",is_demo=True),
      ChangeRequest(cr_key="CR-1048",title="Profile avatar upload",application_id=a1.id,category="File upload",risk_level="Medium",status="Submitted",affected_components="Profile service",affected_endpoints="/api/profile/avatar",acceptance_criteria="Only approved image formats accepted.",is_demo=True),
      ChangeRequest(cr_key="CR-2031",title="Order lookup authorization",application_id=a2.id,category="Access control",risk_level="Critical",status="Submitted",affected_components="Order API",affected_endpoints="/v1/orders/{id}",acceptance_criteria="Users can only read their own orders.",is_demo=True)]
    session.add_all(crs);session.flush()
    session.add_all([ReleaseChangeRequest(release_id=r1.id,change_request_id=crs[0].id),ReleaseChangeRequest(release_id=r1.id,change_request_id=crs[1].id),ReleaseChangeRequest(release_id=r3.id,change_request_id=crs[2].id)])
    tests=[
      TestCase(test_key="TC-AUTH-001",title="Recovery token expiry and replay",category="Authentication",vulnerability_class="Session management",risk_level="High",objective="Verify recovery tokens expire and cannot be reused.",steps="1. Request recovery token.\\n2. Use token once.\\n3. Replay token.",expected_result="Second use is rejected; expired token is rejected.",mandatory=True,regression_eligible=True,current_version=1,is_demo=True),
      TestCase(test_key="TC-UPL-004",title="Avatar upload type validation",category="File upload",vulnerability_class="Input validation",risk_level="Medium",steps="Upload allowed and disallowed extensions; inspect server response and stored object.",expected_result="Disallowed content is rejected and not served.",is_demo=True),
      TestCase(test_key="TC-AC-009",title="Object-level authorization for order IDs",category="Access control",vulnerability_class="IDOR",risk_level="Critical",steps="Authenticate as user A; request user B's order identifier.",expected_result="Request is denied without disclosing order data.",mandatory=True,is_demo=True),
      TestCase(test_key="TC-HEAD-002",title="Security header baseline",category="Configuration",vulnerability_class="Security headers",risk_level="Low",steps="Inspect response headers for approved baseline.",expected_result="Required headers are present with safe values.",mandatory=True,is_demo=True)]
    session.add_all(tests);session.flush()
    for tc in tests:
        session.add(TestCaseVersion(test_case_id=tc.id,version=1,snapshot={"title":tc.title,"steps":tc.steps,"expected_result":tc.expected_result},change_note="Demo seed version"))
    session.flush()
    plan=TestPlan(release_id=r1.id,name="Release 2.4 security test plan",status="Approved",approved_by="Demo Security Lead",is_demo=True)
    plan3=TestPlan(release_id=r3.id,name="Release 1.8 initial plan",status="Draft",is_demo=True)
    session.add_all([plan,plan3]);session.flush()
    ex1=create_test_execution(session,plan,tests[0],e1.id,crs[0].id,"Demo Analyst")
    update_execution_status(session,ex1.id,"Passed","Token replay rejected","Replay received 401.")
    ex2=create_test_execution(session,plan,tests[1],e1.id,crs[1].id,"Demo Analyst")
    update_execution_status(session,ex2.id,"Failed","SVG upload accepted unexpectedly","Fictional demo observation; not a real scan.")
    ex3=create_test_execution(session,plan,tests[3],e1.id,None,"Demo Analyst")
    update_execution_status(session,ex3.id,"Blocked","Waiting on approved header baseline")
    create_test_execution(session,plan3,tests[2],e2.id,crs[2].id,"Demo Analyst")
    f=Finding(finding_key="FND-2026-0041",title="Potential unsafe avatar content handling",description="Fictional demo finding: upload endpoint accepted a disallowed SVG payload.",category="File upload",severity="High",confidence="Medium",business_priority="High",affected_target="/api/profile/avatar",application_id=a1.id,environment_id=e1.id,status="Ready for Retest",remediation="Validate content server-side and store uploads outside executable web paths.",owner="Demo Engineering",is_demo=True)
    session.add(f);session.flush()
    session.add(FindingObservation(finding_id=f.id,release_id=r1.id,change_request_id=crs[1].id,test_execution_id=ex2.id,observation="Fictional observation associated with failed test.",retest_result="Pending"))
    suite,_=create_regression_suite(session,r1.id,r2.id);suite.is_demo=True
    session.add(ActivityEvent(action="demo.seeded",entity_type="Application",entity_id=a1.id,note="Fictional demonstration records created."))
    return True

def clear_demo_data(session):
    # Delete in dependency order, only records explicitly flagged as demo.
    from sqlalchemy import delete
    from sentinel_dast.models import (EvidenceAttachment,ImportedScanFinding,ScanRun,DefectReference,
        RiskAcceptance,Approval,RegressionMembership,RegressionSuite,FindingObservation,Finding,
        TestExecutionHistory,TestExecution,TestPlan,TestSuiteMembership,TestSuite,TestCaseVersion,
        TestCase,ReleaseChangeRequest,ChangeRequest,Release,Environment,Application)
    demo_app_ids=list(session.scalars(select(Application.id).where(Application.is_demo.is_(True))))
    demo_release_ids=list(session.scalars(select(Release.id).where(Release.is_demo.is_(True))))
    demo_cr_ids=list(session.scalars(select(ChangeRequest.id).where(ChangeRequest.is_demo.is_(True))))
    demo_test_ids=list(session.scalars(select(TestCase.id).where(TestCase.is_demo.is_(True))))
    demo_finding_ids=list(session.scalars(select(Finding.id).where(Finding.is_demo.is_(True))))
    demo_plan_ids=list(session.scalars(select(TestPlan.id).where(TestPlan.is_demo.is_(True))))
    demo_exec_ids=list(session.scalars(select(TestExecution.id).where(TestExecution.test_plan_id.in_(demo_plan_ids))))
    for model,field,ids in [
        (EvidenceAttachment,EvidenceAttachment.entity_id,demo_exec_ids),
        (FindingObservation,FindingObservation.finding_id,demo_finding_ids),
        (RiskAcceptance,RiskAcceptance.finding_id,demo_finding_ids),
        (DefectReference,DefectReference.finding_id,demo_finding_ids),
        (Finding,Finding.id,demo_finding_ids),
        (TestExecutionHistory,TestExecutionHistory.execution_id,demo_exec_ids),
        (TestExecution,TestExecution.id,demo_exec_ids),
        (RegressionMembership,RegressionMembership.test_case_id,demo_test_ids),
        (RegressionSuite,RegressionSuite.release_id,demo_release_ids),
        (TestPlan,TestPlan.id,demo_plan_ids),
        (TestCaseVersion,TestCaseVersion.test_case_id,demo_test_ids),
        (TestCase,TestCase.id,demo_test_ids),
        (ReleaseChangeRequest,ReleaseChangeRequest.release_id,demo_release_ids),
        (ReleaseChangeRequest,ReleaseChangeRequest.change_request_id,demo_cr_ids),
        (ChangeRequest,ChangeRequest.id,demo_cr_ids),
        (Release,Release.id,demo_release_ids),
        (Environment,Environment.application_id,demo_app_ids),
        (Application,Application.id,demo_app_ids),
    ]:
        if ids: session.execute(delete(model).where(field.in_(ids)))
