from __future__ import annotations
import hashlib, mimetypes, shutil
from pathlib import Path
from sentinel_dast.config import data_home
from sentinel_dast.models import EvidenceAttachment

MAX_EVIDENCE_BYTES = 25 * 1024 * 1024
ALLOWED_EXTENSIONS = {".png",".jpg",".jpeg",".webp",".pdf",".html",".txt",".log",".json",".xml",".csv",".xlsx",".zip"}

def attach_evidence(session, source_path: str, entity_type: str, entity_id: int, description=""):
    source=Path(source_path)
    if not source.is_file(): raise ValueError("Evidence file does not exist.")
    if source.suffix.lower() not in ALLOWED_EXTENSIONS: raise ValueError("File type is not allowed.")
    size=source.stat().st_size
    if size > MAX_EVIDENCE_BYTES: raise ValueError("Evidence exceeds 25 MiB limit.")
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    target_dir=data_home()/"evidence"/digest[:2]
    target_dir.mkdir(parents=True,exist_ok=True)
    target=target_dir/f"{digest}{source.suffix.lower()}"
    if not target.exists(): shutil.copy2(source,target)
    item=EvidenceAttachment(entity_type=entity_type,entity_id=entity_id,original_filename=source.name,
        stored_path=str(target),sha256=digest,size_bytes=size,
        media_type=mimetypes.guess_type(source.name)[0] or "application/octet-stream",description=description)
    session.add(item)
    return item
