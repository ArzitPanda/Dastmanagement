from __future__ import annotations
from datetime import datetime, timezone
from sqlalchemy import String, Text, DateTime, Boolean, Integer, ForeignKey, UniqueConstraint, Index, JSON
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

def now_utc(): return datetime.now(timezone.utc)

class Base(DeclarativeBase): pass

class AuditMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc, onupdate=now_utc, nullable=False)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    archived: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

class Application(Base, AuditMixin):
    __tablename__ = "applications"
    id: Mapped[int] = mapped_column(primary_key=True)
    app_key: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    description: Mapped[str] = mapped_column(Text, default="")
    business_owner: Mapped[str] = mapped_column(String(160), default="")
    technical_owner: Mapped[str] = mapped_column(String(160), default="")
    technology_stack: Mapped[str] = mapped_column(String(300), default="")
    app_type: Mapped[str] = mapped_column(String(40), default="Web application")
    base_url: Mapped[str] = mapped_column(String(1000), default="")
    auth_method: Mapped[str] = mapped_column(String(100), default="Manual")
    scope: Mapped[str] = mapped_column(Text, default="")
    out_of_scope: Mapped[str] = mapped_column(Text, default="")
    criticality: Mapped[str] = mapped_column(String(30), default="Medium")
    data_sensitivity: Mapped[str] = mapped_column(String(40), default="Internal")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    environments: Mapped[list["Environment"]] = relationship(back_populates="application")
    releases: Mapped[list["Release"]] = relationship(back_populates="application")

class Environment(Base, AuditMixin):
    __tablename__ = "environments"
    __table_args__ = (UniqueConstraint("application_id", "name", name="uq_environment_app_name"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    application_id: Mapped[int] = mapped_column(ForeignKey("applications.id"), index=True)
    name: Mapped[str] = mapped_column(String(60))
    base_url: Mapped[str] = mapped_column(String(1000), default="")
    is_production: Mapped[bool] = mapped_column(Boolean, default=False)
    authorized_for_active_scan: Mapped[bool] = mapped_column(Boolean, default=False)
    application: Mapped[Application] = relationship(back_populates="environments")

class Release(Base, AuditMixin):
    __tablename__ = "releases"
    __table_args__ = (UniqueConstraint("application_id", "version", name="uq_release_app_version"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    release_key: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    application_id: Mapped[int] = mapped_column(ForeignKey("applications.id"), index=True)
    version: Mapped[str] = mapped_column(String(80))
    release_type: Mapped[str] = mapped_column(String(40), default="Minor")
    description: Mapped[str] = mapped_column(Text, default="")
    environment_id: Mapped[int | None] = mapped_column(ForeignKey("environments.id"))
    planned_date: Mapped[str] = mapped_column(String(20), default="")
    actual_date: Mapped[str] = mapped_column(String(20), default="")
    owner: Mapped[str] = mapped_column(String(160), default="")
    business_impact: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(40), default="Draft", index=True)
    signoff_status: Mapped[str] = mapped_column(String(40), default="Pending")
    final_assessment: Mapped[str] = mapped_column(Text, default="")
    application: Mapped[Application] = relationship(back_populates="releases")
    environment: Mapped[Environment | None] = relationship()
    release_crs: Mapped[list["ReleaseChangeRequest"]] = relationship(back_populates="release")

class ChangeRequest(Base, AuditMixin):
    __tablename__ = "change_requests"
    id: Mapped[int] = mapped_column(primary_key=True)
    cr_key: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(240))
    description: Mapped[str] = mapped_column(Text, default="")
    application_id: Mapped[int] = mapped_column(ForeignKey("applications.id"), index=True)
    category: Mapped[str] = mapped_column(String(80), default="Other")
    affected_components: Mapped[str] = mapped_column(Text, default="")
    affected_endpoints: Mapped[str] = mapped_column(Text, default="")
    risk_level: Mapped[str] = mapped_column(String(30), default="Medium")
    business_justification: Mapped[str] = mapped_column(Text, default="")
    implementation_owner: Mapped[str] = mapped_column(String(160), default="")
    submission_date: Mapped[str] = mapped_column(String(20), default="")
    deployment_date: Mapped[str] = mapped_column(String(20), default="")
    acceptance_criteria: Mapped[str] = mapped_column(Text, default="")
    security_impact: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(40), default="Submitted")
    regression_required: Mapped[bool] = mapped_column(Boolean, default=True)
    analyst_notes: Mapped[str] = mapped_column(Text, default="")
    release_links: Mapped[list["ReleaseChangeRequest"]] = relationship(back_populates="change_request")

class ReleaseChangeRequest(Base):
    __tablename__ = "release_change_requests"
    __table_args__ = (UniqueConstraint("release_id", "change_request_id", name="uq_release_cr"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    release_id: Mapped[int] = mapped_column(ForeignKey("releases.id"), index=True)
    change_request_id: Mapped[int] = mapped_column(ForeignKey("change_requests.id"), index=True)
    release: Mapped[Release] = relationship(back_populates="release_crs")
    change_request: Mapped[ChangeRequest] = relationship(back_populates="release_links")

class TestCase(Base, AuditMixin):
    __tablename__ = "test_cases"
    id: Mapped[int] = mapped_column(primary_key=True)
    test_key: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(240), index=True)
    category: Mapped[str] = mapped_column(String(100), default="General")
    vulnerability_class: Mapped[str] = mapped_column(String(100), default="")
    risk_level: Mapped[str] = mapped_column(String(30), default="Medium")
    objective: Mapped[str] = mapped_column(Text, default="")
    preconditions: Mapped[str] = mapped_column(Text, default="")
    steps: Mapped[str] = mapped_column(Text, default="")
    expected_result: Mapped[str] = mapped_column(Text, default="")
    evidence_required: Mapped[str] = mapped_column(Text, default="")
    applicable_types: Mapped[str] = mapped_column(String(200), default="Web application,API")
    framework_mapping: Mapped[str] = mapped_column(String(200), default="")
    automation_eligible: Mapped[bool] = mapped_column(Boolean, default=False)
    regression_eligible: Mapped[bool] = mapped_column(Boolean, default=True)
    mandatory: Mapped[bool] = mapped_column(Boolean, default=False)
    tags: Mapped[str] = mapped_column(String(500), default="")
    current_version: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(30), default="Active")
    versions: Mapped[list["TestCaseVersion"]] = relationship(back_populates="test_case")

class TestCaseVersion(Base):
    __tablename__ = "test_case_versions"
    __table_args__ = (UniqueConstraint("test_case_id", "version", name="uq_testcase_version"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    test_case_id: Mapped[int] = mapped_column(ForeignKey("test_cases.id"), index=True)
    version: Mapped[int] = mapped_column(Integer)
    snapshot: Mapped[dict] = mapped_column(JSON, default=dict)
    change_note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    test_case: Mapped[TestCase] = relationship(back_populates="versions")

class TestSuite(Base, AuditMixin):
    __tablename__ = "test_suites"
    id: Mapped[int] = mapped_column(primary_key=True)
    suite_key: Mapped[str] = mapped_column(String(50), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text, default="")

class TestSuiteMembership(Base):
    __tablename__ = "test_suite_memberships"
    id: Mapped[int] = mapped_column(primary_key=True)
    suite_id: Mapped[int] = mapped_column(ForeignKey("test_suites.id"), index=True)
    test_case_id: Mapped[int] = mapped_column(ForeignKey("test_cases.id"), index=True)
    test_case_version_id: Mapped[int | None] = mapped_column(ForeignKey("test_case_versions.id"))

class TestPlan(Base, AuditMixin):
    __tablename__ = "test_plans"
    id: Mapped[int] = mapped_column(primary_key=True)
    release_id: Mapped[int] = mapped_column(ForeignKey("releases.id"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(40), default="Draft")
    approved_by: Mapped[str] = mapped_column(String(160), default="")
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    executions: Mapped[list["TestExecution"]] = relationship(back_populates="plan")

class TestExecution(Base, AuditMixin):
    __tablename__ = "test_executions"
    __table_args__ = (Index("ix_execution_plan_status", "test_plan_id", "status"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    execution_key: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    test_plan_id: Mapped[int] = mapped_column(ForeignKey("test_plans.id"), index=True)
    test_case_id: Mapped[int] = mapped_column(ForeignKey("test_cases.id"), index=True)
    test_case_version_id: Mapped[int] = mapped_column(ForeignKey("test_case_versions.id"), index=True)
    change_request_id: Mapped[int | None] = mapped_column(ForeignKey("change_requests.id"), index=True)
    environment_id: Mapped[int] = mapped_column(ForeignKey("environments.id"), index=True)
    assignee: Mapped[str] = mapped_column(String(160), default="")
    priority: Mapped[str] = mapped_column(String(30), default="Medium")
    status: Mapped[str] = mapped_column(String(30), default="Not Started", index=True)
    actual_observations: Mapped[str] = mapped_column(Text, default="")
    justification: Mapped[str] = mapped_column(Text, default="")
    tool_reference: Mapped[str] = mapped_column(String(300), default="")
    executed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    plan: Mapped[TestPlan] = relationship(back_populates="executions")
    test_case: Mapped[TestCase] = relationship()
    version: Mapped[TestCaseVersion] = relationship()
    history: Mapped[list["TestExecutionHistory"]] = relationship(back_populates="execution")

class TestExecutionHistory(Base):
    __tablename__ = "test_execution_history"
    id: Mapped[int] = mapped_column(primary_key=True)
    execution_id: Mapped[int] = mapped_column(ForeignKey("test_executions.id"), index=True)
    old_status: Mapped[str] = mapped_column(String(30), default="")
    new_status: Mapped[str] = mapped_column(String(30))
    notes: Mapped[str] = mapped_column(Text, default="")
    actor: Mapped[str] = mapped_column(String(160), default="Local analyst")
    changed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    execution: Mapped[TestExecution] = relationship(back_populates="history")

class Finding(Base, AuditMixin):
    __tablename__ = "findings"
    id: Mapped[int] = mapped_column(primary_key=True)
    finding_key: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(240), index=True)
    description: Mapped[str] = mapped_column(Text, default="")
    category: Mapped[str] = mapped_column(String(100), default="Other")
    severity: Mapped[str] = mapped_column(String(20), default="Medium", index=True)
    confidence: Mapped[str] = mapped_column(String(20), default="Medium")
    business_priority: Mapped[str] = mapped_column(String(20), default="Medium")
    affected_target: Mapped[str] = mapped_column(String(1000), default="")
    application_id: Mapped[int] = mapped_column(ForeignKey("applications.id"), index=True)
    environment_id: Mapped[int] = mapped_column(ForeignKey("environments.id"), index=True)
    status: Mapped[str] = mapped_column(String(40), default="Open", index=True)
    remediation: Mapped[str] = mapped_column(Text, default="")
    owner: Mapped[str] = mapped_column(String(160), default="")
    due_date: Mapped[str] = mapped_column(String(20), default="")
    defect_reference: Mapped[str] = mapped_column(String(200), default="")
    false_positive_reason: Mapped[str] = mapped_column(Text, default="")
    observations: Mapped[list["FindingObservation"]] = relationship(back_populates="finding")

class FindingObservation(Base):
    __tablename__ = "finding_observations"
    id: Mapped[int] = mapped_column(primary_key=True)
    finding_id: Mapped[int] = mapped_column(ForeignKey("findings.id"), index=True)
    release_id: Mapped[int] = mapped_column(ForeignKey("releases.id"), index=True)
    change_request_id: Mapped[int | None] = mapped_column(ForeignKey("change_requests.id"))
    test_execution_id: Mapped[int | None] = mapped_column(ForeignKey("test_executions.id"))
    observation: Mapped[str] = mapped_column(Text, default="")
    retest_result: Mapped[str] = mapped_column(String(40), default="Not Retested")
    closure_evidence: Mapped[str] = mapped_column(Text, default="")
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    finding: Mapped[Finding] = relationship(back_populates="observations")

class DefectReference(Base):
    __tablename__ = "defect_references"
    id: Mapped[int] = mapped_column(primary_key=True)
    finding_id: Mapped[int] = mapped_column(ForeignKey("findings.id"), index=True)
    provider: Mapped[str] = mapped_column(String(80), default="External")
    ticket_key: Mapped[str] = mapped_column(String(160))
    url: Mapped[str] = mapped_column(String(1000), default="")
    status: Mapped[str] = mapped_column(String(60), default="Open")

class RegressionSuite(Base, AuditMixin):
    __tablename__ = "regression_suites"
    id: Mapped[int] = mapped_column(primary_key=True)
    release_id: Mapped[int] = mapped_column(ForeignKey("releases.id"), index=True)
    source_release_id: Mapped[int | None] = mapped_column(ForeignKey("releases.id"))
    name: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(40), default="Planned")

class RegressionMembership(Base):
    __tablename__ = "regression_memberships"
    id: Mapped[int] = mapped_column(primary_key=True)
    suite_id: Mapped[int] = mapped_column(ForeignKey("regression_suites.id"), index=True)
    test_case_id: Mapped[int] = mapped_column(ForeignKey("test_cases.id"), index=True)
    source_release_id: Mapped[int | None] = mapped_column(ForeignKey("releases.id"))
    source_finding_id: Mapped[int | None] = mapped_column(ForeignKey("findings.id"))
    reason: Mapped[str] = mapped_column(Text, default="")

class ScanRun(Base, AuditMixin):
    __tablename__ = "scan_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    scan_key: Mapped[str] = mapped_column(String(80), unique=True)
    application_id: Mapped[int] = mapped_column(ForeignKey("applications.id"), index=True)
    release_id: Mapped[int] = mapped_column(ForeignKey("releases.id"), index=True)
    environment_id: Mapped[int] = mapped_column(ForeignKey("environments.id"), index=True)
    scanner: Mapped[str] = mapped_column(String(80), default="Manual import")
    scanner_version: Mapped[str] = mapped_column(String(80), default="")
    configuration_summary: Mapped[str] = mapped_column(Text, default="")
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    original_report_path: Mapped[str] = mapped_column(String(1000), default="")
    import_status: Mapped[str] = mapped_column(String(40), default="Imported")

class ImportedScanFinding(Base):
    __tablename__ = "imported_scan_findings"
    id: Mapped[int] = mapped_column(primary_key=True)
    scan_run_id: Mapped[int] = mapped_column(ForeignKey("scan_runs.id"), index=True)
    scanner_finding_id: Mapped[str] = mapped_column(String(200), default="")
    normalized_title: Mapped[str] = mapped_column(String(240))
    normalized_severity: Mapped[str] = mapped_column(String(20), default="Informational")
    target: Mapped[str] = mapped_column(String(1000), default="")
    duplicate_candidate_id: Mapped[int | None] = mapped_column(ForeignKey("findings.id"))
    review_status: Mapped[str] = mapped_column(String(40), default="Needs Review")
    raw_summary: Mapped[str] = mapped_column(Text, default="")

class EvidenceAttachment(Base, AuditMixin):
    __tablename__ = "evidence_attachments"
    id: Mapped[int] = mapped_column(primary_key=True)
    entity_type: Mapped[str] = mapped_column(String(60), index=True)
    entity_id: Mapped[int] = mapped_column(Integer, index=True)
    original_filename: Mapped[str] = mapped_column(String(255))
    stored_path: Mapped[str] = mapped_column(String(1000))
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    size_bytes: Mapped[int] = mapped_column(Integer)
    media_type: Mapped[str] = mapped_column(String(120), default="application/octet-stream")
    description: Mapped[str] = mapped_column(Text, default="")

class RiskAcceptance(Base, AuditMixin):
    __tablename__ = "risk_acceptances"
    id: Mapped[int] = mapped_column(primary_key=True)
    finding_id: Mapped[int] = mapped_column(ForeignKey("findings.id"), index=True)
    approver: Mapped[str] = mapped_column(String(160))
    rationale: Mapped[str] = mapped_column(Text)
    accepted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    active: Mapped[bool] = mapped_column(Boolean, default=True)

class Approval(Base, AuditMixin):
    __tablename__ = "approvals"
    id: Mapped[int] = mapped_column(primary_key=True)
    entity_type: Mapped[str] = mapped_column(String(60), index=True)
    entity_id: Mapped[int] = mapped_column(Integer, index=True)
    decision: Mapped[str] = mapped_column(String(40))
    approver: Mapped[str] = mapped_column(String(160))
    rationale: Mapped[str] = mapped_column(Text, default="")
    approved_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)

class ActivityEvent(Base):
    __tablename__ = "activity_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    actor: Mapped[str] = mapped_column(String(160), default="Local analyst")
    action: Mapped[str] = mapped_column(String(100), index=True)
    entity_type: Mapped[str] = mapped_column(String(60), index=True)
    entity_id: Mapped[int] = mapped_column(Integer, index=True)
    before_value: Mapped[dict | None] = mapped_column(JSON)
    after_value: Mapped[dict | None] = mapped_column(JSON)
    note: Mapped[str] = mapped_column(Text, default="")
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc, index=True)

class SavedFilter(Base, AuditMixin):
    __tablename__ = "saved_filters"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160))
    module: Mapped[str] = mapped_column(String(60))
    filter_spec: Mapped[dict] = mapped_column(JSON, default=dict)

class ApplicationConfiguration(Base, AuditMixin):
    __tablename__ = "application_configurations"
    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(160), unique=True)
    value: Mapped[dict] = mapped_column(JSON, default=dict)
