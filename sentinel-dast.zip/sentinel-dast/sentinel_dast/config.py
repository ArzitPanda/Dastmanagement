from __future__ import annotations
import os
from pathlib import Path

APP_NAME = "Sentinel DAST"

def data_home() -> Path:
    path = Path(os.environ.get("SENTINEL_DAST_HOME", Path.home() / ".sentinel-dast")).expanduser()
    path.mkdir(parents=True, exist_ok=True)
    (path / "evidence").mkdir(exist_ok=True)
    (path / "reports").mkdir(exist_ok=True)
    return path

def database_url() -> str:
    return f"sqlite:///{data_home() / 'sentinel.db'}"
