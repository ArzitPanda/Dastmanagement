DARK = """
QWidget { background: #171b22; color: #e6eaf0; font-family: 'Segoe UI', 'Inter', sans-serif; font-size: 10pt; }
QMainWindow, QDialog { background: #171b22; }
QFrame#Sidebar { background: #11151b; border-right: 1px solid #2b323d; }
QLabel#Brand { color: #f2f5f9; font-size: 16pt; font-weight: 700; }
QLabel#PageTitle { color: #f2f5f9; font-size: 20pt; font-weight: 650; }
QLabel#Muted { color: #9ca8b8; }
QPushButton { background: #242b35; border: 1px solid #343e4b; border-radius: 5px; padding: 7px 11px; }
QPushButton:hover { background: #2d3744; border-color: #4e7db5; }
QPushButton:focus, QLineEdit:focus, QComboBox:focus { border: 1px solid #65a7f4; }
QPushButton#NavButton { text-align: left; padding: 10px 12px; border: none; background: transparent; color: #bdc7d5; }
QPushButton#NavButton:checked { background: #25384e; color: #9ac9ff; border-left: 3px solid #5ea5f4; }
QLineEdit, QComboBox, QTextEdit { background: #1d232c; border: 1px solid #333d49; border-radius: 5px; padding: 7px; selection-background-color: #315d8a; }
QTableWidget { background: #1a2028; alternate-background-color: #1e252f; gridline-color: #2d3540; border: 1px solid #2d3540; selection-background-color: #2b4e72; }
QHeaderView::section { background: #222a34; color: #bfcbd9; border: none; border-bottom: 1px solid #3a4552; padding: 8px; font-weight: 600; }
QTabWidget::pane { border: 1px solid #303946; }
QStatusBar { background: #11151b; color: #9ca8b8; }
"""
LIGHT = """
QWidget { background: #f4f6f9; color: #1e2936; font-family: 'Segoe UI', 'Inter', sans-serif; font-size: 10pt; }
QMainWindow, QDialog { background: #f4f6f9; }
QFrame#Sidebar { background: #e9edf3; border-right: 1px solid #d3dae4; }
QLabel#Brand { color: #172334; font-size: 16pt; font-weight: 700; }
QLabel#PageTitle { color: #172334; font-size: 20pt; font-weight: 650; }
QLabel#Muted { color: #637184; }
QPushButton { background: #fff; border: 1px solid #d1d9e3; border-radius: 5px; padding: 7px 11px; }
QPushButton:hover { background: #eaf2fc; border-color: #6e9ed4; }
QPushButton#NavButton { text-align: left; padding: 10px 12px; border: none; background: transparent; color: #334155; }
QPushButton#NavButton:checked { background: #d8e8fa; color: #174c85; border-left: 3px solid #2878c8; }
QLineEdit, QComboBox, QTextEdit { background: #fff; border: 1px solid #cbd5e1; border-radius: 5px; padding: 7px; }
QTableWidget { background: #fff; alternate-background-color: #f6f8fb; gridline-color: #e1e6ed; border: 1px solid #d6dde7; selection-background-color: #d7e9fb; }
QHeaderView::section { background: #edf1f6; color: #334155; border: none; border-bottom: 1px solid #d4dce6; padding: 8px; font-weight: 600; }
QStatusBar { background: #e9edf3; color: #637184; }
"""
