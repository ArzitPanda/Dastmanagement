from __future__ import annotations
from pathlib import Path
from datetime import datetime
from sqlalchemy import select, func, or_
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QMainWindow,QWidget,QFrame,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,
    QLineEdit,QComboBox,QTableWidget,QTableWidgetItem,QStackedWidget,QMessageBox,QFileDialog,
    QInputDialog,QFormLayout,QDialog,QTextEdit,QStatusBar,QHeaderView)
from sentinel_dast.config import data_home
from sentinel_dast.db import session_scope
from sentinel_dast.models import Application,Environment,Release,ChangeRequest,TestCase,TestPlan,TestExecution,Finding,FindingObservation,ActivityEvent
from sentinel_dast.services.workflow import release_metrics, signoff_blockers, transition_release, update_execution_status
from sentinel_dast.services.reporting import export_release_html,export_release_pdf,export_release_xlsx
from sentinel_dast.services.backup import create_backup
from sentinel_dast.services.demo import seed_demo,clear_demo_data
from sentinel_dast.ui.theme import DARK,LIGHT

MODULES=["Overview","Applications","Releases","Change Requests","Test Library","Test Execution","Findings & Defects","Regression Testing","Reports & Evidence","Settings"]
FIELDS={
 "Applications":[("app_key","Application ID"),("name","Name"),("app_type","Type"),("criticality","Criticality"),("technology_stack","Technology stack"),("base_url","Base URL"),("business_owner","Business owner"),("technical_owner","Technical owner")],
 "Releases":[("release_key","Release ID"),("version","Version"),("release_type","Type"),("status","Status"),("signoff_status","Sign-off"),("owner","Owner")],
 "Change Requests":[("cr_key","CR ID"),("title","Title"),("category","Category"),("risk_level","Risk"),("status","Status"),("implementation_owner","Owner")],
 "Test Library":[("test_key","Test case ID"),("title","Title"),("category","Category"),("vulnerability_class","Vulnerability class"),("risk_level","Risk"),("status","Status")],
 "Test Execution":[("execution_key","Execution ID"),("test_case_id","Test case DB ID"),("status","Status"),("assignee","Assignee"),("priority","Priority"),("tool_reference","Tool reference")],
 "Findings & Defects":[("finding_key","Finding ID"),("title","Title"),("severity","Severity"),("confidence","Confidence"),("business_priority","Priority"),("status","Status"),("affected_target","Target"),("owner","Owner")],
 "Regression Testing":[("id","Suite DB ID"),("name","Suite"),("status","Status"),("release_id","Target release DB ID"),("source_release_id","Source release DB ID")],
 "Reports & Evidence":[("release_key","Release ID"),("version","Version"),("status","Status"),("signoff_status","Sign-off"),("owner","Owner")],
 "Settings":[("key","Setting"),("value","Value")],
}
MODELS={"Applications":Application,"Releases":Release,"Change Requests":ChangeRequest,"Test Library":TestCase,
        "Test Execution":TestExecution,"Findings & Defects":Finding,"Regression Testing":None,"Reports & Evidence":Release}
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("Sentinel DAST · Security Testing Operations"); self.resize(1440,900)
        self.theme_dark=True; self.current_module="Overview"; self._build(); self.apply_theme(); self.navigate("Overview")
    def _build(self):
        root=QWidget(); layout=QHBoxLayout(root); layout.setContentsMargins(0,0,0,0); layout.setSpacing(0)
        side=QFrame(); side.setObjectName("Sidebar"); side.setFixedWidth(224); sv=QVBoxLayout(side); sv.setContentsMargins(14,18,14,14)
        brand=QLabel("◈ SENTINEL"); brand.setObjectName("Brand"); sv.addWidget(brand)
        subtitle=QLabel("DAST OPERATIONS"); subtitle.setObjectName("Muted"); sv.addWidget(subtitle); sv.addSpacing(18)
        self.nav_buttons={}
        for name in MODULES:
            b=QPushButton(("◉  " if name=="Overview" else "▸  ")+name); b.setObjectName("NavButton"); b.setCheckable(True); b.clicked.connect(lambda checked=False,n=name:self.navigate(n))
            sv.addWidget(b); self.nav_buttons[name]=b
        sv.addStretch(); foot=QLabel("LOCAL WORKSPACE\nv0.1.0 · DEMO-SAFE"); foot.setObjectName("Muted"); sv.addWidget(foot)
        main=QWidget(); mv=QVBoxLayout(main); mv.setContentsMargins(20,14,20,14); mv.setSpacing(12)
        toolbar=QHBoxLayout(); self.search=QLineEdit(); self.search.setPlaceholderText("Search IDs, titles, endpoints…  (Ctrl+K)"); self.search.returnPressed.connect(self.refresh_current)
        toolbar.addWidget(self.search,1)
        self.context=QComboBox(); self.context.setMinimumWidth(190); self.context.addItem("All applications",None); self.context.currentIndexChanged.connect(self.refresh_current); toolbar.addWidget(self.context)
        quick=QPushButton("+ Quick create"); quick.clicked.connect(self.quick_create); toolbar.addWidget(quick)
        theme=QPushButton("◐ Theme"); theme.clicked.connect(self.toggle_theme); toolbar.addWidget(theme)
        backup=QPushButton("Backup"); backup.clicked.connect(self.backup_db); toolbar.addWidget(backup); mv.addLayout(toolbar)
        self.page_title=QLabel("Overview"); self.page_title.setObjectName("PageTitle"); mv.addWidget(self.page_title)
        self.subtitle_label=QLabel("Release readiness, test execution, and evidence in one workspace."); self.subtitle_label.setObjectName("Muted"); mv.addWidget(self.subtitle_label)
        self.stack=QStackedWidget(); mv.addWidget(self.stack,1)
        self.pages={}
        for name in MODULES:
            page=QWidget(); pl=QVBoxLayout(page); pl.setContentsMargins(0,0,0,0)
            if name=="Overview":
                self.pages[name]=self._overview_page(page,pl)
            elif name=="Settings":
                self.pages[name]=self._settings_page(page,pl)
            else:
                actions=QHBoxLayout()
                add=QPushButton("+ Create"); add.clicked.connect(lambda checked=False,n=name:self.create_record(n))
                refresh=QPushButton("Refresh"); refresh.clicked.connect(self.refresh_current)
                actions.addWidget(add); actions.addWidget(refresh); actions.addStretch()
                if name=="Reports & Evidence":
                    export=QPushButton("Export selected release"); export.clicked.connect(self.export_report); actions.addWidget(export)
                if name=="Releases":
                    transition=QPushButton("Move lifecycle"); transition.clicked.connect(self.move_release); actions.addWidget(transition)
                if name=="Test Execution":
                    result=QPushButton("Record result"); result.clicked.connect(self.record_result); actions.addWidget(result)
                pl.addLayout(actions)
                table=QTableWidget(); table.setAlternatingRowColors(True); table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows); table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers); table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch); table.setSortingEnabled(True)
                pl.addWidget(table,1); self.pages[name]=(page,table)
            self.stack.addWidget(page)
        layout.addWidget(side); layout.addWidget(main,1); self.setCentralWidget(root)
        self.setStatusBar(QStatusBar()); self.statusBar().showMessage(f"Local database · {data_home()/'sentinel.db'}")
        self._refresh_context()
    def _overview_page(self,page,layout):
        self.metric_labels={}
        grid=QHBoxLayout()
        for key,title in [("apps","Applications"),("releases","Active releases"),("signoff","Awaiting sign-off"),("crs","Open CRs"),("high","Open Critical/High"),("pending","Pending tests")]:
            box=QFrame(); box.setFrameShape(QFrame.Shape.StyledPanel); v=QVBoxLayout(box); lab=QLabel("0"); lab.setStyleSheet("font-size:22pt;font-weight:700"); cap=QLabel(title); cap.setObjectName("Muted"); v.addWidget(lab);v.addWidget(cap);grid.addWidget(box);self.metric_labels[key]=lab
        layout.addLayout(grid)
        actions=QHBoxLayout()
        for label,module in [("Plan release","Releases"),("Create CR","Change Requests"),("Add test case","Test Library"),("Record finding","Findings & Defects"),("Generate report","Reports & Evidence")]:
            b=QPushButton(label);b.clicked.connect(lambda checked=False,m=module:self.navigate(m));actions.addWidget(b)
        layout.addLayout(actions)
        self.overview_table=QTableWidget();self.overview_table.setColumnCount(4);self.overview_table.setHorizontalHeaderLabels(["Release","Application","Status","Sign-off blockers"]);self.overview_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch);self.overview_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(QLabel("Release readiness"));layout.addWidget(self.overview_table,1)
        return page
    def _settings_page(self,page,layout):
        note=QLabel("Local workspace settings and data safety");note.setStyleSheet("font-size:14pt;font-weight:600");layout.addWidget(note)
        body=QLabel("Database and evidence are stored locally. SQLite is not encrypted at rest by this application. Use OS disk encryption and protect backups. Demo records are fictional and can be removed separately.")
        body.setWordWrap(True);layout.addWidget(body)
        for text,fn in [("Seed fictional demo data",self.seed_demo),("Clear fictional demo data",self.clear_demo),("Create database backup",self.backup_db),("Open data directory",self.open_data_dir)]:
            b=QPushButton(text);b.clicked.connect(fn);layout.addWidget(b)
        layout.addStretch();return page
    def apply_theme(self): self.setStyleSheet(DARK if self.theme_dark else LIGHT)
    def toggle_theme(self): self.theme_dark=not self.theme_dark;self.apply_theme()
    def _refresh_context(self):
        old=self.context.currentData();self.context.blockSignals(True);self.context.clear();self.context.addItem("All applications",None)
        with session_scope() as s:
            for a in s.scalars(select(Application).where(Application.archived.is_(False)).order_by(Application.name)):
                self.context.addItem(a.name,a.id)
        idx=self.context.findData(old);self.context.setCurrentIndex(max(idx,0));self.context.blockSignals(False)
    def navigate(self,name):
        self.current_module=name
        for n,b in self.nav_buttons.items():b.setChecked(n==name)
        self.page_title.setText(name);self.stack.setCurrentWidget(self.pages[name][0] if isinstance(self.pages[name],tuple) else self.pages[name])
        self.subtitle_label.setText({"Overview":"Release readiness, test execution, and evidence in one workspace.","Releases":"Manage release lifecycle and security sign-off.","Change Requests":"Track change impact, risk, and security coverage.","Test Library":"Reusable, versioned security test cases."}.get(name,"Search, review, and manage security testing records."))
        self.refresh_current()
    def refresh_current(self):
        if self.current_module=="Overview": self.refresh_overview();return
        if self.current_module=="Settings": return
        if self.current_module not in self.pages or not isinstance(self.pages[self.current_module],tuple):return
        table=self.pages[self.current_module][1]; model=MODELS.get(self.current_module)
        if model is None:
            from sentinel_dast.models import RegressionSuite
            model=RegressionSuite
        fields=FIELDS.get(self.current_module,[])
        query=self.search.text().strip().lower()
        with session_scope() as s:
            stmt=select(model).where(model.archived.is_(False)) if hasattr(model,"archived") else select(model)
            app_id=self.context.currentData()
            if app_id and hasattr(model,"application_id"):stmt=stmt.where(model.application_id==app_id)
            rows=s.scalars(stmt.order_by(model.id.desc())).all()
            data=[]
            for row in rows:
                vals=[]
                for key,label in fields:
                    value=getattr(row,key,"")
                    if key=="value" and isinstance(value,dict):value=str(value)
                    vals.append("" if value is None else str(value))
                if query and query not in " ".join(vals).lower():continue
                data.append((row.id,vals))
        table.setSortingEnabled(False);table.clear();table.setColumnCount(len(fields)+1);table.setHorizontalHeaderLabels(["DB ID"]+[x[1] for x in fields]);table.setRowCount(len(data))
        for i,(rid,vals) in enumerate(data):
            table.setItem(i,0,QTableWidgetItem(str(rid)))
            for j,val in enumerate(vals,1):table.setItem(i,j,QTableWidgetItem(val))
        table.setSortingEnabled(True)
    def refresh_overview(self):
        with session_scope() as s:
            app_id=self.context.currentData()
            appq=select(func.count(Application.id)).where(Application.archived.is_(False))
            relq=select(Release).where(Release.archived.is_(False),Release.status.not_in(["Closed","Approved"]))
            crq=select(func.count(ChangeRequest.id)).where(ChangeRequest.archived.is_(False),ChangeRequest.status.not_in(["Closed","Rejected"]))
            findq=select(func.count(Finding.id)).where(Finding.archived.is_(False),Finding.severity.in_(["Critical","High"]),Finding.status.not_in(["Closed","False Positive","Accepted Risk"]))
            execq=select(func.count(TestExecution.id)).where(TestExecution.status.in_(["Not Started","In Progress","Blocked","Needs Retest"]))
            if app_id:
                appq=appq.where(Application.id==app_id);relq=relq.where(Release.application_id==app_id);crq=crq.where(ChangeRequest.application_id==app_id);findq=findq.where(Finding.application_id==app_id)
            self.metric_labels["apps"].setText(str(s.scalar(appq) or 0))
            releases=s.scalars(relq).all();self.metric_labels["releases"].setText(str(len(releases)))
            self.metric_labels["signoff"].setText(str(sum(1 for r in releases if r.status in {"Ready for Review","Blocked"})))
            self.metric_labels["crs"].setText(str(s.scalar(crq) or 0));self.metric_labels["high"].setText(str(s.scalar(findq) or 0));self.metric_labels["pending"].setText(str(s.scalar(execq) or 0))
            table=self.overview_table;table.setRowCount(len(releases))
            for i,r in enumerate(releases):
                app=s.get(Application,r.application_id); blockers=signoff_blockers(s,r.id)
                for j,val in enumerate([r.version,app.name if app else "—",r.status,"; ".join(blockers) if blockers else "No configured blockers"]):
                    table.setItem(i,j,QTableWidgetItem(str(val)))
    def quick_create(self):
        items=["Application","Release","Change Request","Test Case","Finding"]
        choice,ok=QInputDialog.getItem(self,"Quick create","Create a record:",items,0,False)
        if ok:
            module={"Application":"Applications","Release":"Releases","Change Request":"Change Requests","Test Case":"Test Library","Finding":"Findings & Defects"}[choice]
            self.navigate(module);self.create_record(module)
    def create_record(self,module):
        if module in {"Reports & Evidence","Regression Testing","Test Execution"}:
            QMessageBox.information(self,"Workflow action","Use the selected record and the contextual actions for this workflow. This starter build keeps high-risk transitions explicit.");return
        model=MODELS.get(module)
        if not model:return
        fields=FIELDS.get(module,[])
        dlg=QDialog(self);dlg.setWindowTitle(f"Create {module}");dlg.resize(520,600);form=QFormLayout(dlg);inputs={}
        with session_scope() as s:
            apps=s.scalars(select(Application).where(Application.archived.is_(False))).all()
            envs=s.scalars(select(Environment).where(Environment.archived.is_(False))).all()
        for key,label in fields:
            if key in {"id","test_case_id","value","release_key"} and module=="Reports & Evidence":continue
            if key in {"id","test_case_id"}:continue
            w=QTextEdit() if key in {"description","steps","expected_result","objective","remediation","affected_components","affected_endpoints","acceptance_criteria","business_justification","security_impact","scope","out_of_scope"} else QLineEdit()
            if key=="status":
                w=QComboBox();opts={"Releases":["Draft","Planned","In Testing","Blocked","Ready for Review","Rejected"],"Change Requests":["Submitted","In Progress","Implemented","Closed"],"Test Library":["Active","Deprecated"],"Findings & Defects":["Open","Triaged","Confirmed","In Remediation","Fixed","Ready for Retest","Reopened","Accepted Risk","False Positive","Closed"]}.get(module,["Open","In Progress","Closed"])
                w.addItems(opts)
            if key=="severity":w=QComboBox();w.addItems(["Critical","High","Medium","Low","Informational"])
            if key=="confidence":w=QComboBox();w.addItems(["High","Medium","Low"])
            form.addRow(label,w);inputs[key]=w
        if module in {"Releases","Change Requests","Findings & Defects"}:
            appw=QComboBox();[(appw.addItem(a.name,a.id)) for a in apps];form.addRow("Application",appw);inputs["application_id"]=appw
        if module in {"Releases","Findings & Defects"}:
            envw=QComboBox();envw.addItem("Select environment",None);[(envw.addItem(f"{e.name} · {e.base_url}",e.id)) for e in envs];form.addRow("Environment",envw);inputs["environment_id"]=envw
        if module=="Releases":
            envw=QComboBox();envw.addItem("Not set",None);[(envw.addItem(e.name,e.id)) for e in envs];form.addRow("Environment",envw);inputs["environment_id"]=envw
        buttons=QHBoxLayout();save=QPushButton("Save record");cancel=QPushButton("Cancel");buttons.addWidget(cancel);buttons.addWidget(save);form.addRow(buttons);cancel.clicked.connect(dlg.reject)
        def do_save():
            try:
                obj=model()
                for key,w in inputs.items():
                    if isinstance(w,QComboBox):val=w.currentData() if key.endswith("_id") else w.currentText()
                    elif isinstance(w,QTextEdit):val=w.toPlainText()
                    else:val=w.text().strip()
                    if key=="environment_id" and val is None:continue
                    if key=="application_id" and val is None:raise ValueError("Choose an application.")
                    setattr(obj,key,val)
                if module=="Applications":
                    if not obj.app_key or not obj.name:raise ValueError("Application ID and name are required.")
                if module=="Releases":
                    if not obj.application_id or not obj.version:raise ValueError("Application and version are required.")
                    obj.release_key=obj.release_key or f"REL-{obj.application_id}-{obj.version}"
                if module=="Findings & Defects" and not obj.environment_id:raise ValueError("Select the environment where the finding was observed.")
                if module=="Change Requests" and (not obj.cr_key or not obj.title):raise ValueError("CR ID and title are required.")
                if module=="Test Library":
                    if not obj.test_key or not obj.title:raise ValueError("Test case ID and title are required.")
                if module=="Findings & Defects" and (not obj.finding_key or not obj.title):raise ValueError("Finding ID and title are required.")
                with session_scope() as s:
                    s.add(obj);s.flush()
                    if module=="Applications":
                        s.add(Environment(application_id=obj.id,name="QA",base_url=obj.base_url,authorized_for_active_scan=False))
                    s.add(ActivityEvent(action="record.created",entity_type=module,entity_id=obj.id,after_value={"id":obj.id}))
                dlg.accept();self._refresh_context();self.refresh_current()
            except Exception as exc:QMessageBox.warning(dlg,"Could not save",str(exc))
        save.clicked.connect(do_save);dlg.exec()
    def move_release(self):
        table=self.pages["Releases"][1];row=table.currentRow()
        if row<0:QMessageBox.information(self,"Select release","Select a release row first.");return
        rid=int(table.item(row,0).text())
        status,ok=QInputDialog.getItem(self,"Release lifecycle","Move release to:",["Planned","In Testing","Blocked","Ready for Review","Rejected","Closed"],0,False)
        if not ok:return
        try:
            with session_scope() as s:transition_release(s,rid,status)
            self.refresh_current()
        except Exception as exc:QMessageBox.warning(self,"Transition rejected",str(exc))
    def record_result(self):
        table=self.pages["Test Execution"][1];row=table.currentRow()
        if row<0:QMessageBox.information(self,"Select execution","Select an execution row first.");return
        eid=int(table.item(row,0).text())
        status,ok=QInputDialog.getItem(self,"Record result","Execution status:",["In Progress","Passed","Failed","Blocked","Not Applicable","Needs Retest"],0,False)
        if not ok:return
        notes,ok=QInputDialog.getMultiLineText(self,"Execution notes","Actual observations / justification:")
        if not ok:return
        try:
            with session_scope() as s:update_execution_status(s,eid,status,notes,notes)
            self.refresh_current()
        except Exception as exc:QMessageBox.warning(self,"Could not record result",str(exc))
    def export_report(self):
        table=self.pages["Reports & Evidence"][1];row=table.currentRow()
        if row<0:QMessageBox.information(self,"Select release","Select a release row first.");return
        release_id=int(table.item(row,0).text())
        kind,ok=QInputDialog.getItem(self,"Export release assessment","Format:",["PDF","HTML","Excel"],0,False)
        if not ok:return
        path,_=QFileDialog.getSaveFileName(self,"Save report",str(data_home()/f"release-assessment.{ {'PDF':'pdf','HTML':'html','Excel':'xlsx'}[kind]}"))
        if not path:return
        try:
            with session_scope() as s:
                fn={"PDF":export_release_pdf,"HTML":export_release_html,"Excel":export_release_xlsx}[kind];fn(s,release_id,path)
            QMessageBox.information(self,"Report generated",f"Report saved to:\n{path}")
        except Exception as exc:QMessageBox.warning(self,"Report failed",str(exc))
    def backup_db(self):
        try:path=create_backup();QMessageBox.information(self,"Backup created",f"Database backup created:\n{path}")
        except Exception as exc:QMessageBox.warning(self,"Backup unavailable",str(exc))
    def seed_demo(self):
        with session_scope() as s:created=seed_demo(s)
        self._refresh_context();self.refresh_current();QMessageBox.information(self,"Demo data","Fictional demo data added." if created else "Demo data already exists.")
    def clear_demo(self):
        answer=QMessageBox.question(self,"Clear demo data","Remove only records marked as fictional demo data?")
        if answer!=QMessageBox.StandardButton.Yes:return
        with session_scope() as s:clear_demo_data(s)
        self._refresh_context();self.refresh_current();QMessageBox.information(self,"Demo data","Fictional demo records removed.")
    def open_data_dir(self):
        import os,subprocess,sys
        path=str(data_home())
        try:
            if sys.platform.startswith("win"):os.startfile(path)
            elif sys.platform=="darwin":subprocess.Popen(["open",path])
            else:subprocess.Popen(["xdg-open",path])
        except Exception as exc:QMessageBox.warning(self,"Could not open directory",str(exc))
